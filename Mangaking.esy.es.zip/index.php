<?php
require 'content' . DIRECTORY_SEPARATOR . 'index.php';