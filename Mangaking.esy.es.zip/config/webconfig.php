<?php
	define('DOMAIN','');
	$servername = "localhost";
	$username = "u232194151_mking";
	$password = "khoa1245";
	$dbname = "u232194151_mking";
?>