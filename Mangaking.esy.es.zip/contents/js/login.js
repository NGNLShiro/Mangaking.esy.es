	function activelogin(){
		var x = document.getElementById("login-result");
		x.classList.remove("active-login");
	}
	function closeloingresult(){
		var y = document.getElementById("login-result");
		y.classList.add("active-login");
	}